define([], () => {
  'use strict';

  let fields = {
    "Trackin": "Tracking",
    "IdTracking": 0,
    "Description": "Descripción",
    "Validator": "Validador",
    "FechaEntrega": "Fecha de entrega",
    "Status": "Estado",
    "UserEmail": "",
    "CreateDate": "Fecha de creación",
    "CreateBy": "Creado por",
    "LastUpdateDate": "Ultima fecha de actualización",
    "LastUpdateBy": "Actualizado por",
    "FILE": "Adjunto"
  };
  class PageModule {
    searchDisplayField(prop) {
      try {
        return fields[prop];
      } catch (error) {
        return "";
      }
    }
    convertStream(stream) {
      return new Blob([stream], { type: "application/octet-stream" });
    }
    validLovInitial(arrayIn) {
      if (typeof arrayIn == "string") {
        return [];
      } else {
        return arrayIn;
      }
    }

    getDateNow() {
      return Date.now();
    }

    validForm(form) {
      var tracker = document.getElementById(form);

      if (tracker.valid === "valid") {
        return true;
      } else {
        tracker.showMessages();
        tracker.focusOn("@firstInvalidShown");
        return false;
      }
    }


    parseDateToNumber(srt) {
      return srt ? Date.parse(srt) : "";
    }

    displayStatus(inp) {
      let lang = localStorage.getItem('vbcs.languageSwitcherApplication.locale');
      if (!lang || lang === "root" || lang === "es") {
        switch (inp) {
          case "OPEN":
            return "Abierto";
          case "CLOSED":
            return "Cerrado";
          case "PROCESS":
            return "Procesado";
          case "CANCEL":
            return "Cancelado";
          default:
            return "";
        }
      } else if (lang === "en") {
        switch (inp) {
          case "OPEN":
            return "Open";
          case "CLOSED":
            return "Closed";
          case "PROCESS":
            return "Process";
          case "CANCEL":
            return "Cancel";
          default:
            return "";
        }
      }

    }

    langStatusHistory(value) {
      let lang = localStorage.getItem('vbcs.languageSwitcherApplication.locale');
      if (!lang || lang === "root" || lang === "es") {
        return value === "CREATE" ? "Creación" : "Eliminado";
      } else if (lang === "en") {
        return value === "CREATE" ? "Create" : "Delete";
      }
    }
    displayHistoryValue(value, field) {
      let find = this.displayStatus(value);
      if (find) {
        return find;
      } else {
        return value == "CREATE" ? this.langStatusHistory(value) : value === "DELETE" ? this.langStatusHistory(value) : this.isDateTabla(value, field);
      }
    }
    isDateTabla(value, field) {
      if (field === "FechaEntrega" || field === "CreateDate" || field === "LastUpdateDate") {
        return this.displayDateFormat(value);
      } else {
        return value;
      }
    }
    validarStateDate(date, dateCreate, status) {
      if (status == "CLOSED" || status == "CANCEL") {
        return status;
      } else {
        let test = Date.now() - 5270588000;
        let hoy = new Date();
        let entrega = new Date(date);
        if (!date && dateCreate < test) {
          return "CANCEL";
        } else if (entrega < hoy) {
          return "CLOSED";
        } else {
          return status;
        }
      }
    }
    //aqui me quede xdd
    processSelectionTrack(readable) {
      let files = readable.Files ?? [];
      let r = {
        "Trackin": readable.Trackin,
        "IdTracking": readable.IdTracking,
        "Description": readable.Description,
        "Validator": readable.Validator,
        "FechaEntrega": readable.FechaEntrega,
        "Status": this.validarStateDate(readable.FechaEntrega, readable.CreateDate, readable.Status),
        "UserEmail": readable.UserEmail,
        "CreateDate": readable.CreateDate,
        "CreateBy": readable.CreateBy,
        "LastUpdateDate": readable.LastUpdateDate,
        "LastUpdateBy": readable.LastUpdateBy,
      };

      return {
        data: r,
        files: files
      };
    }

    beforInsert(readable, user, compareObj) {
      let r = {
        "Trackin": readable.Trackin,
        "IdTracking": readable.IdTracking,
        "Description": readable.Description,
        "Validator": readable.Validator,
        "FechaEntrega": readable.FechaEntrega ? this.getDayUtc(readable.FechaEntrega) : "",
        "Status": readable.IdTracking ? compareObj?.Validator !== readable.Validator ? "PROCESS" : readable.Status : readable.Status,
        "UserEmail": readable.UserEmail,
        "CreateDate": readable.CreateDate,
        "CreateBy": readable.CreateBy,
        "LastUpdateDate": Date.now(),
        "LastUpdateBy": user
      };
      return r;
    }


    formDataFile(file) {
      let formData = new FormData();
      return formData.append("files", file);
    }


    filtNewFiles(arrFiles) {
      if (arrFiles.length === 0) {
        return [];
      } else {
        return arrFiles.filter((p) => p.operation === "CREATE");
      }
    }

    validDete(arraFiles) {
      let ne = arraFiles.filter((p) => p?.operation === "DELETE");
      if (ne.length == 0) {
        return false;
      } else {
        return true;
      }
    }
    convertDeleteFiles(arraFiles) {
      let files = arraFiles.filter((p) => p?.operation === "DELETE");
      let returner = [];
      for (let i = 0; i < files.length; i++) {
        const element = files[i];
        returner.push({
          IdAttach: element.IdAttachment,
          "FileHas": element.FileHash,
          "FileExt": element.FileExt,
          "FileName": element.FileName,
          "IdTrack": element.IdTracking
        });
      }
      return {
        Files: returner
      };
    }


    displayDateFormat(date) {
      if (!date) {
        return "";
      } else {
        var options = { timezone: "America/Mexico_City", year: 'numeric', month: 'short', day: 'numeric', hour: "numeric", minute: 'numeric', hour12: "true" };
        var today = new Date(date);
        //today.setHours(today.getHours() - 1);
        return today.toLocaleDateString("es-MX", options).toUpperCase();
      }
    }

    compareValues(track, oldTrack, user) {
      let arrChanges = [];
      for (const prop in track) {
        if (prop !== "Files" && prop !== "Trackin" && prop !== "IdTracking" && prop !== "LastUpdateDate" && prop !== "UserEmail" && prop !== "LastUpdateBy") {
          if (prop == "FechaEntrega") {
            if (new Date(track[prop]).toJSON() !== new Date(oldTrack[prop]).toJSON()) {
              arrChanges.push({
                IdTrack: track.IdTracking,
                IdAttach: 0,
                NewValue: track[prop],
                OldValue: oldTrack[prop],
                CreateDate: new Date(),
                Field: prop,
                CreateBy: user
              });
            }
          } else {
            if (track[prop] !== oldTrack[prop]) {
              arrChanges.push({
                IdTrack: track.IdTracking,
                IdAttach: 0,
                NewValue: track[prop],
                OldValue: oldTrack[prop],
                CreateDate: new Date(),
                Field: prop,
                CreateBy: user
              });
            }
          }
        }
      }
      return arrChanges;
    }

    getFileExtension3(filename) {
      return filename.slice((filename.lastIndexOf(".") - 1 >>> 0) + 2);
    }

    procesFilesField(arrayFile, idTrack, user) {
      if (arrayFile.length == 0) {
        return "";
      } else {
        let file = arrayFile[0];
        let f = {
          id: Date.now(),
          FileName: file.name,
          FileExt: "." + this.getFileExtension3(file.name),
          Description: "",
          IdTracking: idTrack,
          CreateDate: Date.now(),
          CreateBy: user,
          LastUpdateDate: Date.now(),
          LastUpdateBy: user,
          operation: "CREATE",
          ObjFile: file
        };

        return f;
      }
    }

    /**
     *
     * @param {Array} arg1
     * @return {String}
     */
    generateIdFilea(arg1) {
      let num = 5;
      if (arg1) {
        let files = [];
        for (let i = 0; i < arg1.length; i++) {
          arg1[i].id = num;
          files.push(arg1[i]);
          num = num + 5;
        }
        return files;
      } else {
        return [];
      }
    }

    isExistTrack(arrayTrack, id) {
      let find = arrayTrack.filter((x) => x.IdTracking === id);
      if (find.length === 0) {
        return false;
      } else {
        return true;
      }
    }


    downloadOci(data, filename) {
      this.downloadBlob(data, filename);
    }

    downloadBlob(blob, name) {
      // Convert your blob into a Blob URL (a special url that points to an object in the browser's memory)
      const blobUrl = URL.createObjectURL(blob);

      // Create a link element
      const link = document.createElement("a");

      // Set link's href to point to the Blob URL
      link.href = blobUrl;
      link.download = name;

      // Append link to the body
      document.body.appendChild(link);

      // Dispatch click event on the link
      // This is necessary as link.click() does not work on the latest firefox
      link.dispatchEvent(
        new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window
        })
      );

      // Remove link from body
      document.body.removeChild(link);
    }

    getDayUtc(date) {
      //2023-07-22T00:00:00
      if (date) {
        return new Date(date).toJSON();
      } else {
        return new Date().toJSON();
      }

    }

    /**
     *
     * @param {Array} data
     * @param {String} seleccion
     * @return {Object}
     */
    BuscarEnLov(data, seleccion) {
      let filtra = data.filter((x) => x.Trackin === seleccion);
      if (filtra.length === 0) {
        return {
          data: data.push({ Trackin: seleccion }),
          load: true
        };
      } else {
        return {
          data: null,
          load: false
        };
      }
    }

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    convertUpperCase(arg1) {
      return arg1.toUpperCase();
    }

    buscarStatusTabla(status, fechaCreacion, fechaEntrega) {
      return this.displayStatus(this.validarStateDate(fechaEntrega, fechaCreacion, status));
    }
  }

  return PageModule;
});
