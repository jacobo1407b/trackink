define([], () => {
  'use strict';

  class FlowModule {
  }
  
  return FlowModule;
});
