define([], () => {
  'use strict';

  class PageModule {
    setAppLanguage(selectedLocale) {
      if (selectedLocale) {
        window.localStorage.setItem('vbcs.languageSwitcherApplication.locale', selectedLocale);
      }
    }
  }

  return PageModule;
});
